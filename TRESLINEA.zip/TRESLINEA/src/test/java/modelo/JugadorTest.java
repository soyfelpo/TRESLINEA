package edu.universidadlibre.modelo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JugadorTest {

    @Test
    void debeCrearJugadorConNombreUsuario() {

        Jugador jugador = new Jugador("Duvan");

        assertEquals("Duvan", jugador.obtenerNombreUsuario());
    }

    @Test
    void debeConservarElNombreDelJugador() {

        Jugador jugador = new Jugador("Carlos");

        assertNotNull(jugador.obtenerNombreUsuario());
        assertEquals("Carlos", jugador.obtenerNombreUsuario());
    }

    @Test
    void debeGenerarUnIdentificadorUnico() {

        Jugador jugador = new Jugador("Duvan");

        assertNotNull(jugador.obtenerId());
    }

    @Test
    void dosJugadoresDebenTenerIdentificadoresDiferentes() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        assertNotEquals(jugador1.obtenerId(), jugador2.obtenerId());
    }

    @Test
    void debeRegistrarLaFechaDeCreacion() {

        Jugador jugador = new Jugador("Duvan");

        assertNotNull(jugador.obtenerFechaRegistro());
    }
}