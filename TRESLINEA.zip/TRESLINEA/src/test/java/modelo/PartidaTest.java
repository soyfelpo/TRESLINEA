package edu.universidadlibre.modelo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PartidaTest {

    @Test
    void debeAsignarSimboloXAlPrimerJugador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertEquals("X", partida.obtenerSimboloDe(jugador1));
    }

    @Test
    void debeAsignarSimboloOAlSegundoJugador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertEquals("O", partida.obtenerSimboloDe(jugador2));
    }

    @Test
    void debeGuardarLosDosJugadores() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertEquals(jugador1, partida.obtenerJugadorX());
        assertEquals(jugador2, partida.obtenerJugadorO());
    }

    @Test
    void debeIniciarConUnJuegoNuevo() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertNotNull(partida.obtenerJuego());
        assertEquals("X", partida.obtenerJuego().obtenerTurno());
    }

    @Test
    void debeIdentificarAlGanadorDeLaPartida() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        assertEquals(jugador1, partida.obtenerGanador());
    }

    @Test
    void debeRetornarNullCuandoNoHayGanador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertNull(partida.obtenerGanador());
    }

    @Test
    void debeIniciarConLaPartidaSinFinalizar() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertFalse(partida.estaFinalizada());
    }

    @Test
    void debeFinalizarCuandoHayUnGanador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        assertTrue(partida.estaFinalizada());
    }

    @Test
    void debeDetectarEmpateCuandoElTableroEstaLlenoSinGanador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(0, 1);
        juego.jugar(0, 2);
        juego.jugar(1, 1);
        juego.jugar(1, 0);
        juego.jugar(1, 2);
        juego.jugar(2, 1);
        juego.jugar(2, 0);
        juego.jugar(2, 2);

        assertTrue(partida.hayEmpate());
    }

    @Test
    void debeGenerarUnIdentificadorUnico() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertNotNull(partida.obtenerId());
    }

    @Test
    void dosPartidasDebenTenerIdentificadoresDiferentes() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida1 = new Partida(jugador1, jugador2);
        Partida partida2 = new Partida(jugador1, jugador2);

        assertNotEquals(partida1.obtenerId(), partida2.obtenerId());
    }

    @Test
    void debeRegistrarLaFechaDeInicio() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertNotNull(partida.obtenerFechaInicio());
    }

    @Test
    void debeIniciarSinFechaDeFinalizacion() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertNull(partida.obtenerFechaFin());
    }

    @Test
    void debeIniciarConEstadoEnCurso() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        assertEquals("EN_CURSO", partida.obtenerEstado());
    }

    @Test
    void debeCambiarEstadoCuandoLaPartidaFinaliza() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        assertEquals("FINALIZADA", partida.obtenerEstado());
        assertNotNull(partida.obtenerFechaFin());
    }
}