package modelo;

import edu.universidadlibre.modelo.Tablero;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TableroTest {

    @Test
    void tableroDebeIniciarVacio() {
        Tablero tablero = new Tablero();

        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                assertEquals("", tablero.obtenerFicha(fila, columna));
            }
        }
    }

    @Test
    void debeColocarFichaXEnUnaCasilla() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");

        assertEquals("X", tablero.obtenerFicha(0, 0));
    }

    @Test
    void debeColocarFichaOEnUnaCasilla() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(1, 1, "O");

        assertEquals("O", tablero.obtenerFicha(1, 1));
    }

    @Test
    void noDebePermitirOcuparUnaCasillaDosVeces() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");

        boolean resultado = tablero.colocarFicha(0, 0, "O");

        assertFalse(resultado);
        assertEquals("X", tablero.obtenerFicha(0, 0));
    }

    @Test
    void noDebePermitirPosicionesFueraDelTablero() {
        Tablero tablero = new Tablero();

        boolean resultado = tablero.colocarFicha(3, 0, "X");

        assertFalse(resultado);
    }

    @Test
    void noDebePermitirFichasInvalidas() {
        Tablero tablero = new Tablero();

        boolean resultado = tablero.colocarFicha(0, 0, "A");

        assertFalse(resultado);
    }

    @Test
    void noDebePermitirPosicionesNegativas() {
        Tablero tablero = new Tablero();

        boolean resultado = tablero.colocarFicha(-1, 0, "X");

        assertFalse(resultado);
    }

    @Test
    void debeDetectarTresFichasXEnUnaFila() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(0, 1, "X");
        tablero.colocarFicha(0, 2, "X");

        assertTrue(tablero.hayGanador());
    }

    @Test
    void debeDetectarTresFichasOEnUnaColumna() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "O");
        tablero.colocarFicha(1, 0, "O");
        tablero.colocarFicha(2, 0, "O");

        assertTrue(tablero.hayGanador());
    }

    @Test
    void debeDetectarTresFichasEnDiagonal() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(1, 1, "X");
        tablero.colocarFicha(2, 2, "X");

        assertTrue(tablero.hayGanador());
    }

    @Test
    void noDebeDetectarGanadorCuandoNoHayTresFichasIguales() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(0, 1, "O");
        tablero.colocarFicha(0, 2, "X");

        assertFalse(tablero.hayGanador());
    }

    @Test
    void debeDetectarCuandoElTableroEstaLleno() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(0, 1, "O");
        tablero.colocarFicha(0, 2, "X");
        tablero.colocarFicha(1, 0, "X");
        tablero.colocarFicha(1, 1, "O");
        tablero.colocarFicha(1, 2, "O");
        tablero.colocarFicha(2, 0, "O");
        tablero.colocarFicha(2, 1, "X");
        tablero.colocarFicha(2, 2, "X");

        assertTrue(tablero.estaLleno());
    }

    @Test
    void debeDetectarEmpateCuandoElTableroEstaLlenoYSinGanador() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(0, 1, "O");
        tablero.colocarFicha(0, 2, "X");
        tablero.colocarFicha(1, 0, "X");
        tablero.colocarFicha(1, 1, "O");
        tablero.colocarFicha(1, 2, "O");
        tablero.colocarFicha(2, 0, "O");
        tablero.colocarFicha(2, 1, "X");
        tablero.colocarFicha(2, 2, "X");

        assertTrue(tablero.hayEmpate());
    }

    @Test
    void debeIdentificarAlJugadorXComoGanador() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "X");
        tablero.colocarFicha(0, 1, "X");
        tablero.colocarFicha(0, 2, "X");

        assertEquals("X", tablero.obtenerGanador());
    }

    @Test
    void debeIdentificarAlJugadorOComoGanador() {
        Tablero tablero = new Tablero();

        tablero.colocarFicha(0, 0, "O");
        tablero.colocarFicha(1, 0, "O");
        tablero.colocarFicha(2, 0, "O");

        assertEquals("O", tablero.obtenerGanador());
    }

    @Test
    void debeRetornarNullCuandoNoHayGanador() {
        Tablero tablero = new Tablero();

        assertNull(tablero.obtenerGanador());
    }
}