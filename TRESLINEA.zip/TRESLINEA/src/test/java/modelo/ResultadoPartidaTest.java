package edu.universidadlibre.modelo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ResultadoPartidaTest {

    @Test
    void debeIdentificarAlGanador() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertEquals(jugador1, resultado.obtenerGanador());
    }

    @Test
    void debeIdentificarAlPerdedor() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertEquals(jugador2, resultado.obtenerPerdedor());
    }

    @Test
    void debeIdentificarCuandoLaPartidaEsUnEmpate() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(0, 1);
        juego.jugar(0, 2);
        juego.jugar(1, 1);
        juego.jugar(1, 0);
        juego.jugar(1, 2);
        juego.jugar(2, 2);
        juego.jugar(2, 0);
        juego.jugar(2, 1);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertTrue(resultado.esEmpate());
    }

    @Test
    void debeIdentificarCuandoLaPartidaNoEsUnEmpate() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertFalse(resultado.esEmpate());
    }

    @Test
    void debeIdentificarVictoriaDeX() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(0, 2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertEquals("VICTORIA_X", resultado.obtenerTipoResultado());
    }

    @Test
    void debeIdentificarVictoriaDeO() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(1, 0);
        juego.jugar(0, 1);
        juego.jugar(1, 1);
        juego.jugar(2, 0);
        juego.jugar(1, 2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertEquals("VICTORIA_O", resultado.obtenerTipoResultado());
    }

    @Test
    void debeIdentificarResultadoEmpate() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        Juego juego = partida.obtenerJuego();

        juego.jugar(0, 0);
        juego.jugar(0, 1);
        juego.jugar(0, 2);
        juego.jugar(1, 1);
        juego.jugar(1, 0);
        juego.jugar(1, 2);
        juego.jugar(2, 2);
        juego.jugar(2, 0);
        juego.jugar(2, 1);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertEquals("EMPATE", resultado.obtenerTipoResultado());
    }

    @Test
    void noDebeTenerResultadoMientrasLaPartidaEsteEnCurso() {

        Jugador jugador1 = new Jugador("Duvan");
        Jugador jugador2 = new Jugador("Carlos");

        Partida partida = new Partida(jugador1, jugador2);

        ResultadoPartida resultado = new ResultadoPartida(partida);

        assertNull(resultado.obtenerTipoResultado());
    }
}