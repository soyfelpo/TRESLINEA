package modelo;

import edu.universidadlibre.modelo.Juego;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JuegoTest {

    @Test
    void elJuegoDebeIniciarConTurnoDeX() {

        Juego juego = new Juego();

        assertEquals("X", juego.obtenerTurno());
    }

    @Test
    void despuesDeJugarXDebeSerTurnoDeO() {

        Juego juego = new Juego();

        juego.jugar(0, 0);

        assertEquals("O", juego.obtenerTurno());
    }

    @Test
    void despuesDeJugarODebeSerTurnoDeX() {

        Juego juego = new Juego();

        juego.jugar(0, 0);
        juego.jugar(1, 1);

        assertEquals("X", juego.obtenerTurno());
    }

    @Test
    void noDebeCambiarTurnoCuandoLaCasillaEstaOcupada() {

        Juego juego = new Juego();

        juego.jugar(0, 0);

        boolean resultado = juego.jugar(0, 0);

        assertFalse(resultado);
        assertEquals("O", juego.obtenerTurno());
    }

    @Test
    void noDebeCambiarTurnoCuandoLaPosicionEsInvalida() {

        Juego juego = new Juego();

        boolean resultado = juego.jugar(3, 0);

        assertFalse(resultado);
        assertEquals("X", juego.obtenerTurno());
    }

    @Test
    void noDebePermitirJugarDespuesDeUnGanador() {

        Juego juego = new Juego();

        juego.jugar(0, 0); // X
        juego.jugar(1, 0); // O
        juego.jugar(0, 1); // X
        juego.jugar(1, 1); // O
        juego.jugar(0, 2); // X gana

        boolean resultado = juego.jugar(2, 2);

        assertFalse(resultado);
    }

    @Test
    void noDebePermitirJugarDespuesDeUnEmpate() {

        Juego juego = new Juego();

        juego.jugar(0, 0); // X
        juego.jugar(0, 1); // O
        juego.jugar(0, 2); // X
        juego.jugar(1, 1); // O
        juego.jugar(1, 0); // X
        juego.jugar(1, 2); // O
        juego.jugar(2, 1); // X
        juego.jugar(2, 0); // O
        juego.jugar(2, 2); // X

        boolean resultado = juego.jugar(2, 2);

        assertFalse(resultado);
    }
}