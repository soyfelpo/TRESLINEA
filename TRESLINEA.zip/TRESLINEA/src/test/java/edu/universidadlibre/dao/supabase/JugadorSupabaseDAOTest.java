
package edu.universidadlibre.dao.supabase;

import edu.universidadlibre.configuracion.SesionSupabase;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JugadorSupabaseDAOTest {

    private final JugadorSupabaseDAO dao =
            new JugadorSupabaseDAO();

    @Test
    void noDebeConsultarCuandoLaSesionEsNula() {

        String resultado = dao.buscarNombreUsuario(null);

        assertNull(resultado);
    }

    @Test
    void noDebeConsultarCuandoLaSesionEstaInactiva() {

        SesionSupabase sesion = new SesionSupabase(
                null,
                "refresh123",
                "usuario123",
                "correo@test.com"
        );

        String resultado = dao.buscarNombreUsuario(sesion);

        assertNull(resultado);
    }

    @Test
    void debeAceptarUnaSesionActiva() {

        SesionSupabase sesion = new SesionSupabase(
                "token123",
                "refresh123",
                "usuario123",
                "correo@test.com"
        );

        assertTrue(sesion.estaActiva());
    }
}
