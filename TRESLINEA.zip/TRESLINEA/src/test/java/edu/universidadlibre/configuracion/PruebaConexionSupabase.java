package edu.universidadlibre.configuracion;
public class PruebaConexionSupabase {
    public static void main(String[] args) {

        try {
            String clave = ConexionSupabase.obtenerClave();
            System.out.println("Variable de entorno encontrada.");
            System.out.println("Conexión configurada correctamente.");
            System.out.println("URL de Supabase: "
                    + ConexionSupabase.obtenerUrl("/rest/v1/"));
        } catch (Exception e) {
            System.out.println("Error al configurar Supabase:");
            System.out.println(e.getMessage());
        }
    }
}
