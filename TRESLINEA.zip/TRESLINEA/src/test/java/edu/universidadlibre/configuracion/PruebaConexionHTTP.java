package edu.universidadlibre.configuracion;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;
public class PruebaConexionHTTP {
    public static void main(String[] args) {
        try {
            HttpRequest solicitud = HttpRequest.newBuilder()
                    .uri(ConexionSupabase.obtenerUrl(
                            "/rest/v1/jugadores?select=id&limit=1"
                    ))
                    .header("apikey", ConexionSupabase.obtenerClave())
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> respuesta =
                    ConexionSupabase.obtenerCliente().send(
                            solicitud,
                            HttpResponse.BodyHandlers.ofString()
                    );
            System.out.println("Código HTTP: " + respuesta.statusCode());
            System.out.println("Respuesta: " + respuesta.body());
            if (respuesta.statusCode() == 200) {
                System.out.println("Consulta a Supabase exitosa.");
            } else if (respuesta.statusCode() == 401
                    || respuesta.statusCode() == 403) {
                System.out.println("La API respondió, pero requiere autenticación "
                        + "o permisos según las políticas RLS.");
            } else {
                System.out.println("Revisar configuración de Supabase.");
            }
        } catch (IOException e) {
            System.out.println("Error de comunicación: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Solicitud interrumpida.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
