package edu.universidadlibre.configuracion;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class SesionSupabaseTest {
    @Test
    void debeGuardarLosDatosDeLaSesion() {
        SesionSupabase sesion = new SesionSupabase(
                "token123",
                "refresh123",
                "usuario123",
                "correo@test.com"
        );
        assertEquals("token123", sesion.obtenerAccessToken());
        assertEquals("refresh123", sesion.obtenerRefreshToken());
        assertEquals("usuario123", sesion.obtenerIdUsuario());
        assertEquals("correo@test.com", sesion.obtenerCorreo());
    }
    @Test
    void debeEstarActivaCuandoTieneAccessToken() {
        SesionSupabase sesion = new SesionSupabase(
                "token123",
                "refresh123",
                "usuario123",
                "correo@test.com"
        );
        assertTrue(sesion.estaActiva());
    }
    @Test
    void debeEstarInactivaCuandoNoTieneAccessToken() {
        SesionSupabase sesion = new SesionSupabase(
                null,
                "refresh123",
                "usuario123",
                "correo@test.com"
        );
        assertFalse(sesion.estaActiva());
    }
    @Test
    void debeCerrarLaSesion() {
        SesionSupabase sesion = new SesionSupabase(
                "token123",
                "refresh123",
                "usuario123",
                "correo@test.com"
        );
        sesion.cerrarSesion();
        assertFalse(sesion.estaActiva());
        assertNull(sesion.obtenerAccessToken());
        assertNull(sesion.obtenerRefreshToken());
        assertNull(sesion.obtenerIdUsuario());
        assertNull(sesion.obtenerCorreo());
    }
}
