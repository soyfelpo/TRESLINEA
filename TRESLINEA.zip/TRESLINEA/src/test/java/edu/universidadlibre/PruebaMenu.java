package edu.universidadlibre;
import edu.universidadlibre.presentacion.VentanaMenuPrincipal;

import javax.swing.SwingUtilities;

public class PruebaMenu {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            VentanaMenuPrincipal ventana =
                    new VentanaMenuPrincipal("Jugador");

            ventana.setVisible(true);
        });
    }
}
