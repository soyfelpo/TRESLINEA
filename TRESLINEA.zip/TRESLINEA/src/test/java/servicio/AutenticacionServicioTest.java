
package edu.universidadlibre.servicio;

import edu.universidadlibre.dao.AutenticacionDAO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AutenticacionServicioTest {

    private static class AutenticacionDAOFalso implements AutenticacionDAO {

        private String correoRegistrado;
        private String contrasenaRegistrada;
        private String nombreUsuarioRegistrado;

        private String correoInicioSesion;
        private String contrasenaInicioSesion;

        @Override
        public String registrar(
                String correo,
                String contrasena,
                String nombreUsuario) {

            correoRegistrado = correo;
            contrasenaRegistrada = contrasena;
            nombreUsuarioRegistrado = nombreUsuario;

            return "REGISTRO_EXITOSO";
        }

        @Override
        public String iniciarSesion(
                String correo,
                String contrasena) {

            correoInicioSesion = correo;
            contrasenaInicioSesion = contrasena;

            return "INICIO_SESION_EXITOSO";
        }
    }

    private final AutenticacionServicio servicio =
            new AutenticacionServicio();

    @Test
    void debeRechazarCorreoVacio() {

        String resultado = servicio.validarDatosRegistro(
                "", "123456", "jugador1"
        );

        assertEquals("El correo es obligatorio", resultado);
    }

    @Test
    void debeRechazarContrasenaVacia() {

        String resultado = servicio.validarDatosRegistro(
                "jugador@gmail.com", "", "jugador1"
        );

        assertEquals("La contraseña es obligatoria", resultado);
    }

    @Test
    void debeRechazarNombreUsuarioVacio() {

        String resultado = servicio.validarDatosRegistro(
                "jugador@gmail.com", "123456", ""
        );

        assertEquals("El nombre de usuario es obligatorio", resultado);
    }

    @Test
    void debeRechazarCorreoInvalido() {

        String resultado = servicio.validarDatosRegistro(
                "correoIncorrecto", "123456", "jugador1"
        );

        assertEquals("El correo no tiene un formato válido", resultado);
    }

    @Test
    void debeRechazarNombreUsuarioMayorA30Caracteres() {

        String resultado = servicio.validarDatosRegistro(
                "jugador@gmail.com",
                "123456",
                "jugador123456789012345678901234"
        );

        assertEquals(
                "El nombre de usuario no puede superar 30 caracteres",
                resultado
        );
    }

    @Test
    void debeAceptarDatosCorrectos() {

        String resultado = servicio.validarDatosRegistro(
                "jugador@gmail.com",
                "123456",
                "jugador1"
        );

        assertNull(resultado);
    }

    @Test
    void debeRegistrarJugadorConDatosCorrectos() {

        AutenticacionDAOFalso dao = new AutenticacionDAOFalso();
        AutenticacionServicio servicio = new AutenticacionServicio(dao);

        String resultado = servicio.registrar(
                "jugador@gmail.com",
                "123456",
                "jugador1"
        );

        assertEquals("REGISTRO_EXITOSO", resultado);
        assertEquals("jugador@gmail.com", dao.correoRegistrado);
        assertEquals("123456", dao.contrasenaRegistrada);
        assertEquals("jugador1", dao.nombreUsuarioRegistrado);
    }

    @Test
    void debeRechazarRegistroConCorreoVacio() {

        AutenticacionDAOFalso dao = new AutenticacionDAOFalso();
        AutenticacionServicio servicio = new AutenticacionServicio(dao);

        String resultado = servicio.registrar(
                "", "123456", "jugador1"
        );

        assertEquals("El correo es obligatorio", resultado);
        assertNull(dao.correoRegistrado);
    }

    @Test
    void debeIniciarSesionConDatosCorrectos() {

        AutenticacionDAOFalso dao = new AutenticacionDAOFalso();
        AutenticacionServicio servicio = new AutenticacionServicio(dao);

        String resultado = servicio.iniciarSesion(
                "jugador@gmail.com",
                "123456"
        );

        assertEquals("INICIO_SESION_EXITOSO", resultado);
        assertEquals("jugador@gmail.com", dao.correoInicioSesion);
        assertEquals("123456", dao.contrasenaInicioSesion);
    }
}
