package edu.universidadlibre.modelo;

import java.time.LocalDateTime;
import java.util.UUID;

public class Partida {

    private UUID id;
    private Jugador jugadorX;
    private Jugador jugadorO;
    private Juego juego;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;
    private String estado;

    public Partida(Jugador jugador1, Jugador jugador2) {

        this.id = UUID.randomUUID();

        this.jugadorX = jugador1;
        this.jugadorO = jugador2;

        this.juego = new Juego();

        this.fechaInicio = LocalDateTime.now();
        this.fechaFin = null;

        this.estado = "EN_CURSO";
    }

    public UUID obtenerId() {

        return id;
    }

    public Jugador obtenerJugadorX() {

        return jugadorX;
    }

    public Jugador obtenerJugadorO() {

        return jugadorO;
    }

    public Juego obtenerJuego() {

        return juego;
    }

    public String obtenerSimboloDe(Jugador jugador) {

        if (jugador.equals(jugadorX)) {
            return "X";
        }

        if (jugador.equals(jugadorO)) {
            return "O";
        }

        return null;
    }

    public Jugador obtenerGanador() {

        actualizarEstado();

        String simboloGanador = juego.obtenerGanador();

        if ("X".equals(simboloGanador)) {
            return jugadorX;
        }

        if ("O".equals(simboloGanador)) {
            return jugadorO;
        }

        return null;
    }

    public LocalDateTime obtenerFechaInicio() {

        return fechaInicio;
    }

    public LocalDateTime obtenerFechaFin() {

        actualizarEstado();

        return fechaFin;
    }

    public String obtenerEstado() {

        actualizarEstado();

        return estado;
    }

    public boolean estaFinalizada() {

        actualizarEstado();

        return estado.equals("FINALIZADA");
    }

    public boolean hayEmpate() {

        actualizarEstado();

        return juego.obtenerTablero().hayEmpate();
    }

    private void actualizarEstado() {

        if (!estado.equals("FINALIZADA")
                && (juego.obtenerGanador() != null
                || juego.obtenerTablero().hayEmpate())) {

            estado = "FINALIZADA";
            fechaFin = LocalDateTime.now();
        }
    }
}