
package edu.universidadlibre.modelo;

import java.time.LocalDateTime;
import java.util.UUID;

public class Jugador {

    private UUID id;
    private String nombreUsuario;
    private LocalDateTime fechaRegistro;

    // Constructor para jugadores creados localmente y pruebas
    public Jugador(String nombreUsuario) {

        this.id = UUID.randomUUID();
        this.nombreUsuario = nombreUsuario;
        this.fechaRegistro = LocalDateTime.now();
    }

    // Constructor para jugadores registrados en Supabase
    public Jugador(String nombreUsuario, UUID id) {

        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.fechaRegistro = LocalDateTime.now();
    }

    public UUID obtenerId() {

        return id;
    }

    public String obtenerNombreUsuario() {

        return nombreUsuario;
    }

    public LocalDateTime obtenerFechaRegistro() {

        return fechaRegistro;
    }
}
