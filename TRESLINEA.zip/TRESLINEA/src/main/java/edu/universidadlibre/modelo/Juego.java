package edu.universidadlibre.modelo;

public class Juego {

    private Tablero tablero;
    private String turno;

    public Juego() {

        tablero = new Tablero();
        turno = "X";
    }

    public String obtenerTurno() {

        return turno;
    }

    public boolean jugar(int fila, int columna) {

        if (tablero.hayGanador() || tablero.hayEmpate()) {
            return false;
        }

        boolean resultado = tablero.colocarFicha(fila, columna, turno);

        if (!resultado) {
            return false;
        }

        if (turno.equals("X")) {
            turno = "O";
        } else {
            turno = "X";
        }

        return true;
    }

    public Tablero obtenerTablero() {

        return tablero;
    }

    public String obtenerGanador() {

        return tablero.obtenerGanador();
    }
}