
package edu.universidadlibre.modelo;

public class RankingJugador {

    private String nombreUsuario;
    private int partidasJugadas;
    private int victorias;
    private int empates;
    private int derrotas;

    public RankingJugador(
            String nombreUsuario,
            int partidasJugadas,
            int victorias,
            int empates,
            int derrotas) {

        this.nombreUsuario = nombreUsuario;
        this.partidasJugadas = partidasJugadas;
        this.victorias = victorias;
        this.empates = empates;
        this.derrotas = derrotas;
    }

    public String obtenerNombreUsuario() {
        return nombreUsuario;
    }

    public int obtenerPartidasJugadas() {
        return partidasJugadas;
    }

    public int obtenerVictorias() {
        return victorias;
    }

    public int obtenerEmpates() {
        return empates;
    }

    public int obtenerDerrotas() {
        return derrotas;
    }
}
