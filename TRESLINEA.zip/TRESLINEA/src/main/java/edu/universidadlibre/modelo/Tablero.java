package edu.universidadlibre.modelo;

public class Tablero {

    private String[][] casillas;

    public Tablero() {

        casillas = new String[3][3];

        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                casillas[fila][columna] = "";
            }
        }
    }

    public boolean colocarFicha(int fila, int columna, String ficha) {

        if (fila < 0 || fila >= 3 || columna < 0 || columna >= 3) {
            return false;
        }

        if (!"X".equals(ficha) && !"O".equals(ficha)) {
            return false;
        }

        if (!casillas[fila][columna].equals("")) {
            return false;
        }

        casillas[fila][columna] = ficha;

        return true;
    }

    public String obtenerFicha(int fila, int columna) {

        if (fila < 0 || fila >= 3 || columna < 0 || columna >= 3) {
            return null;
        }

        return casillas[fila][columna];
    }

    public String obtenerGanador() {

        // Comprobar filas
        for (int fila = 0; fila < 3; fila++) {

            if (!casillas[fila][0].equals("")
                    && casillas[fila][0].equals(casillas[fila][1])
                    && casillas[fila][1].equals(casillas[fila][2])) {

                return casillas[fila][0];
            }
        }

        // Comprobar columnas
        for (int columna = 0; columna < 3; columna++) {

            if (!casillas[0][columna].equals("")
                    && casillas[0][columna].equals(casillas[1][columna])
                    && casillas[1][columna].equals(casillas[2][columna])) {

                return casillas[0][columna];
            }
        }

        // Diagonal principal
        if (!casillas[0][0].equals("")
                && casillas[0][0].equals(casillas[1][1])
                && casillas[1][1].equals(casillas[2][2])) {

            return casillas[0][0];
        }

        // Diagonal secundaria
        if (!casillas[0][2].equals("")
                && casillas[0][2].equals(casillas[1][1])
                && casillas[1][1].equals(casillas[2][0])) {

            return casillas[0][2];
        }

        return null;
    }

    public boolean hayGanador() {

        return obtenerGanador() != null;
    }

    public boolean estaLleno() {

        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {

                if (casillas[fila][columna].equals("")) {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean hayEmpate() {

        return estaLleno() && !hayGanador();
    }
}