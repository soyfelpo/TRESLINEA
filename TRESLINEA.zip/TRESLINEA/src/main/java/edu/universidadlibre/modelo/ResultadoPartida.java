package edu.universidadlibre.modelo;

public class ResultadoPartida {

    private Partida partida;

    public ResultadoPartida(Partida partida) {

        this.partida = partida;
    }

    public Jugador obtenerGanador() {

        return partida.obtenerGanador();
    }

    public Jugador obtenerPerdedor() {

        Jugador ganador = obtenerGanador();

        if (ganador == null) {
            return null;
        }

        if (ganador.equals(partida.obtenerJugadorX())) {
            return partida.obtenerJugadorO();
        }

        return partida.obtenerJugadorX();
    }

    public boolean esEmpate() {

        return partida.hayEmpate();
    }

    public String obtenerTipoResultado() {

        if (!partida.estaFinalizada()) {
            return null;
        }

        if (esEmpate()) {
            return "EMPATE";
        }

        if (obtenerGanador().equals(partida.obtenerJugadorX())) {
            return "VICTORIA_X";
        }

        return "VICTORIA_O";
    }
}