
package edu.universidadlibre;

import edu.universidadlibre.dao.supabase.AutenticacionSupabaseDAO;
import edu.universidadlibre.dao.supabase.JugadorSupabaseDAO;
import edu.universidadlibre.servicio.AutenticacionServicio;
import edu.universidadlibre.configuracion.SesionSupabase;

import java.util.Scanner;

public class AutenticacionPrincipal {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        AutenticacionSupabaseDAO autenticacionDAO =
                new AutenticacionSupabaseDAO();

        JugadorSupabaseDAO jugadorDAO =
                new JugadorSupabaseDAO();

        AutenticacionServicio servicio =
                new AutenticacionServicio(autenticacionDAO);

        System.out.println("================================");
        System.out.println("          TRES EN LINEA");
        System.out.println("        INICIO DE SESION");
        System.out.println("================================");

        System.out.print("Correo electrónico: ");
        String correo = teclado.nextLine();

        System.out.print("Contraseña: ");
        String contrasena = teclado.nextLine();

        System.out.println("\nIniciando sesión...");

        String resultado = servicio.iniciarSesion(
                correo,
                contrasena
        );

        if ("INICIO_SESION_EXITOSO".equals(resultado)) {

            SesionSupabase sesion =
                    autenticacionDAO.obtenerSesion();

            System.out.println("\n¡Inicio de sesión exitoso!");

            String nombreUsuario =
                    jugadorDAO.buscarNombreUsuario(sesion);

            if (nombreUsuario != null) {

                System.out.println(
                        "¡Bienvenido, " + nombreUsuario + "!"
                );

            } else {

                System.out.println(
                        "No fue posible recuperar el perfil."
                );
            }

            System.out.println(
                    "Sesión activa: " + sesion.estaActiva()
            );

        } else {

            System.out.println("\nNo se pudo iniciar sesión.");
            System.out.println("Resultado: " + resultado);
        }

        teclado.close();
    }
}
