
package edu.universidadlibre.presentacion;

import edu.universidadlibre.dao.supabase.AutenticacionSupabaseDAO;
import edu.universidadlibre.servicio.AutenticacionServicio;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistro extends JFrame {

    private JTextField campoCorreo;
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JPasswordField campoConfirmarContrasena;
    private JButton botonRegistrar;
    private JLabel mensaje;

    private AutenticacionServicio servicio;

    public VentanaRegistro() {

        AutenticacionSupabaseDAO dao =
                new AutenticacionSupabaseDAO();

        servicio = new AutenticacionServicio(dao);

        configurarVentana();
        crearComponentes();
    }

    private void configurarVentana() {

        setTitle("Tres en Línea - Registro");
        setSize(450, 620);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void crearComponentes() {

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(27, 31, 42));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 35, 7, 35);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel titulo = new JLabel(
                "CREAR CUENTA",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(titulo, gbc);

        JLabel subtitulo = new JLabel(
                "Regístrate para comenzar a jugar",
                SwingConstants.CENTER
        );

        subtitulo.setForeground(new Color(180, 190, 205));

        gbc.gridy = 1;
        panel.add(subtitulo, gbc);

        gbc.gridy = 2;
        panel.add(crearEtiqueta("Correo electrónico"), gbc);

        campoCorreo = new JTextField();
        configurarCampo(campoCorreo);

        gbc.gridy = 3;
        panel.add(campoCorreo, gbc);

        gbc.gridy = 4;
        panel.add(crearEtiqueta("Nombre de usuario"), gbc);

        campoUsuario = new JTextField();
        configurarCampo(campoUsuario);

        gbc.gridy = 5;
        panel.add(campoUsuario, gbc);

        gbc.gridy = 6;
        panel.add(crearEtiqueta("Contraseña"), gbc);

        campoContrasena = new JPasswordField();
        configurarCampo(campoContrasena);

        gbc.gridy = 7;
        panel.add(campoContrasena, gbc);

        gbc.gridy = 8;
        panel.add(crearEtiqueta("Confirmar contraseña"), gbc);

        campoConfirmarContrasena = new JPasswordField();
        configurarCampo(campoConfirmarContrasena);

        gbc.gridy = 9;
        panel.add(campoConfirmarContrasena, gbc);

        botonRegistrar = new JButton("CREAR CUENTA");
        botonRegistrar.setFont(new Font("Arial", Font.BOLD, 15));
        botonRegistrar.setBackground(new Color(49, 118, 150));
        botonRegistrar.setForeground(Color.WHITE);
        botonRegistrar.setFocusPainted(false);
        botonRegistrar.setBorderPainted(false);

        gbc.gridy = 10;
        gbc.insets = new Insets(18, 35, 8, 35);
        panel.add(botonRegistrar, gbc);

        mensaje = new JLabel(" ", SwingConstants.CENTER);
        mensaje.setForeground(new Color(255, 120, 120));
        mensaje.setFont(new Font("Arial", Font.PLAIN, 12));

        gbc.gridy = 11;
        gbc.insets = new Insets(8, 20, 8, 20);
        panel.add(mensaje, gbc);

        botonRegistrar.addActionListener(e -> registrar());

        add(panel);
    }

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 13));

        return etiqueta;
    }

    private void configurarCampo(JTextField campo) {

        campo.setFont(new Font("Arial", Font.PLAIN, 14));
        campo.setPreferredSize(new Dimension(300, 35));
        campo.setBackground(new Color(34, 40, 49));
        campo.setForeground(Color.WHITE);
        campo.setCaretColor(Color.WHITE);

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(65, 75, 90)
                        ),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                )
        );
    }

    private void registrar() {

        String correo = campoCorreo.getText().trim();
        String usuario = campoUsuario.getText().trim();

        String contrasena = new String(
                campoContrasena.getPassword()
        );

        String confirmarContrasena = new String(
                campoConfirmarContrasena.getPassword()
        );

        if (correo.isBlank() || usuario.isBlank()
                || contrasena.isBlank()
                || confirmarContrasena.isBlank()) {

            mensaje.setText("Completa todos los campos.");
            return;
        }

        if (!contrasena.equals(confirmarContrasena)) {

            mensaje.setText("Las contraseñas no coinciden.");
            return;
        }

        botonRegistrar.setEnabled(false);
        mensaje.setForeground(Color.WHITE);
        mensaje.setText("Registrando jugador...");

        SwingWorker<String, Void> trabajador = new SwingWorker<>() {

            @Override
            protected String doInBackground() {

                return servicio.registrar(
                        correo,
                        contrasena,
                        usuario
                );
            }

            @Override
            protected void done() {

                botonRegistrar.setEnabled(true);

                try {

                    String resultado = get();

                    if ("REGISTRO_PENDIENTE_CONFIRMACION".equals(resultado)
                            || "REGISTRO_EXITOSO".equals(resultado)) {

                        JOptionPane.showMessageDialog(
                                VentanaRegistro.this,
                                "Cuenta creada correctamente.\n"
                                        + "Revisa tu correo para confirmar "
                                        + "tu cuenta.",
                                "Registro exitoso",
                                JOptionPane.INFORMATION_MESSAGE
                        );

                        dispose();

                    } else {

                        mensaje.setForeground(
                                new Color(255, 120, 120)
                        );

                        mensaje.setText(resultado);
                    }

                } catch (Exception e) {

                    mensaje.setForeground(
                            new Color(255, 120, 120)
                    );

                    mensaje.setText("Error al registrar la cuenta.");
                }
            }
        };

        trabajador.execute();
    }
}
