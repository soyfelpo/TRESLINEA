
package edu.universidadlibre.presentacion;

import edu.universidadlibre.configuracion.SesionSupabase;

import javax.swing.*;
import java.awt.*;

public class VentanaMenuPrincipal extends JFrame {

    private String nombreUsuario;
    private SesionSupabase sesion;

    public VentanaMenuPrincipal(String nombreUsuario) {
        this(nombreUsuario, null);
    }

    public VentanaMenuPrincipal(
            String nombreUsuario,
            SesionSupabase sesion) {

        this.nombreUsuario = nombreUsuario;
        this.sesion = sesion;

        setTitle("Tres en Línea");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        crearComponentes();
    }

    private void crearComponentes() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(248, 249, 251));

        JLabel titulo = new JLabel(
                "Tres en Línea",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 38));
        titulo.setForeground(Color.WHITE);

        JPanel encabezado = new JPanel();
        encabezado.setBackground(new Color(30, 55, 82));
        encabezado.add(titulo);
        encabezado.setPreferredSize(new Dimension(850, 115));

        principal.add(encabezado, BorderLayout.NORTH);

        JPanel tablero = new JPanel(new GridLayout(3, 3, 5, 5));
        tablero.setPreferredSize(new Dimension(300, 300));
        tablero.setBackground(new Color(30, 55, 82));

        String[] fichas = {
                "X", "O", "X",
                "O", "X", "O",
                "X", "", "O"
        };

        for (String ficha : fichas) {

            JLabel casilla = new JLabel(
                    ficha,
                    SwingConstants.CENTER
            );

            casilla.setFont(new Font("Arial", Font.BOLD, 55));
            casilla.setForeground(new Color(30, 55, 82));
            casilla.setBackground(Color.WHITE);
            casilla.setOpaque(true);

            tablero.add(casilla);
        }

        JPanel panelTablero = new JPanel(new GridBagLayout());
        panelTablero.setBackground(new Color(248, 249, 251));
        panelTablero.add(tablero);

        JPanel opciones = new JPanel();

        opciones.setLayout(
                new BoxLayout(opciones, BoxLayout.Y_AXIS)
        );

        opciones.setBackground(new Color(248, 249, 251));
        opciones.setBorder(
                BorderFactory.createEmptyBorder(55, 25, 30, 25)
        );

        JLabel bienvenida = new JLabel(
                "Bienvenido, " + nombreUsuario
        );

        bienvenida.setFont(new Font("Arial", Font.BOLD, 23));
        bienvenida.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Selecciona una opción");
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        opciones.add(bienvenida);
        opciones.add(Box.createVerticalStrut(12));
        opciones.add(subtitulo);
        opciones.add(Box.createVerticalStrut(35));

        JButton jugar = crearBoton("JUGAR");
        JButton ranking = crearBoton("RANKING");
        JButton perfil = crearBoton("MI PERFIL");
        JButton cerrar = crearBoton("CERRAR SESIÓN");

        opciones.add(jugar);
        opciones.add(Box.createVerticalStrut(15));
        opciones.add(ranking);
        opciones.add(Box.createVerticalStrut(15));
        opciones.add(perfil);
        opciones.add(Box.createVerticalStrut(15));
        opciones.add(cerrar);

        JPanel contenido = new JPanel(new GridLayout(1, 2));
        contenido.add(panelTablero);
        contenido.add(opciones);

        principal.add(contenido, BorderLayout.CENTER);

        JLabel pie = new JLabel(
                "Tres en Línea - Juego de mesa",
                SwingConstants.CENTER
        );

        principal.add(pie, BorderLayout.SOUTH);

        jugar.addActionListener(e -> {

            VentanaInicioSesion ventana =
                    new VentanaInicioSesion(
                            nombreUsuario,
                            sesion
                    );

            ventana.setVisible(true);
            dispose();
        });

        ranking.addActionListener(e -> {

            VentanaRanking ventana =
                    new VentanaRanking(
                            nombreUsuario,
                            sesion
                    );

            ventana.setVisible(true);
            dispose();
        });

        // Abrir el perfil del jugador
        perfil.addActionListener(e -> {

            VentanaPerfil ventana =
                    new VentanaPerfil(
                            nombreUsuario,
                            sesion
                    );

            ventana.setVisible(true);
            dispose();
        });

        cerrar.addActionListener(e -> {

            int respuesta = JOptionPane.showConfirmDialog(
                    this,
                    "¿Deseas cerrar sesión?",
                    "Cerrar sesión",
                    JOptionPane.YES_NO_OPTION
            );

            if (respuesta == JOptionPane.YES_OPTION) {

                if (sesion != null) {
                    sesion.cerrarSesion();
                }

                dispose();
                new VentanaInicioSesion().setVisible(true);
            }
        });

        add(principal);
    }

    private JButton crearBoton(String texto) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Arial", Font.BOLD, 15));
        boton.setBackground(new Color(39, 83, 125));
        boton.setForeground(Color.WHITE);
        boton.setPreferredSize(new Dimension(280, 48));
        boton.setMaximumSize(new Dimension(280, 48));
        boton.setFocusPainted(false);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);

        return boton;
    }
}

