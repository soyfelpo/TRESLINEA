
package edu.universidadlibre.presentacion;

import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.dao.supabase.RankingSupabaseDAO;
import edu.universidadlibre.modelo.RankingJugador;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VentanaPerfil extends JFrame {

    private String nombreUsuario;
    private SesionSupabase sesion;

    private JLabel etiquetaNombre;
    private JLabel etiquetaPartidas;
    private JLabel etiquetaVictorias;
    private JLabel etiquetaEmpates;
    private JLabel etiquetaDerrotas;
    private JLabel etiquetaEstado;

    public VentanaPerfil(
            String nombreUsuario,
            SesionSupabase sesion) {

        this.nombreUsuario = nombreUsuario;
        this.sesion = sesion;

        setTitle("Mi Perfil - Tres en Línea");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        crearComponentes();
        cargarPerfil();
    }

    private void crearComponentes() {

        Color azulOscuro = new Color(30, 55, 82);
        Color azulBoton = new Color(39, 83, 125);
        Color fondo = new Color(248, 249, 251);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(fondo);

        JLabel titulo = new JLabel(
                "MI PERFIL",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 27));
        titulo.setForeground(Color.WHITE);

        JPanel encabezado = new JPanel();
        encabezado.setBackground(azulOscuro);
        encabezado.add(titulo);
        encabezado.setPreferredSize(new Dimension(600, 85));

        principal.add(encabezado, BorderLayout.NORTH);

        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
        contenido.setBackground(fondo);
        contenido.setBorder(
                BorderFactory.createEmptyBorder(30, 70, 20, 70)
        );

        etiquetaNombre = crearEtiqueta(
                "Jugador: " + nombreUsuario, 21, true
        );

        etiquetaPartidas = crearEtiqueta(
                "Partidas jugadas: Cargando...", 16, false
        );

        etiquetaVictorias = crearEtiqueta(
                "Victorias: Cargando...", 16, false
        );

        etiquetaEmpates = crearEtiqueta(
                "Empates: Cargando...", 16, false
        );

        etiquetaDerrotas = crearEtiqueta(
                "Derrotas: Cargando...", 16, false
        );

        contenido.add(etiquetaNombre);
        contenido.add(Box.createVerticalStrut(30));
        contenido.add(etiquetaPartidas);
        contenido.add(Box.createVerticalStrut(18));
        contenido.add(etiquetaVictorias);
        contenido.add(Box.createVerticalStrut(18));
        contenido.add(etiquetaEmpates);
        contenido.add(Box.createVerticalStrut(18));
        contenido.add(etiquetaDerrotas);

        principal.add(contenido, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBackground(fondo);
        panelInferior.setBorder(
                BorderFactory.createEmptyBorder(10, 30, 20, 30)
        );

        etiquetaEstado = new JLabel(
                "Cargando información...",
                SwingConstants.CENTER
        );

        JButton botonActualizar = new JButton("ACTUALIZAR");
        botonActualizar.setBackground(azulBoton);
        botonActualizar.setForeground(Color.WHITE);
        botonActualizar.setFocusPainted(false);

        JButton botonVolver = new JButton("VOLVER");
        botonVolver.setBackground(azulOscuro);
        botonVolver.setForeground(Color.WHITE);
        botonVolver.setFocusPainted(false);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botones.setBackground(fondo);
        botones.add(botonActualizar);
        botones.add(botonVolver);

        panelInferior.add(etiquetaEstado, BorderLayout.CENTER);
        panelInferior.add(botones, BorderLayout.SOUTH);

        principal.add(panelInferior, BorderLayout.SOUTH);

        botonActualizar.addActionListener(e -> cargarPerfil());

        botonVolver.addActionListener(e -> {
            new VentanaMenuPrincipal(
                    nombreUsuario,
                    sesion
            ).setVisible(true);

            dispose();
        });

        add(principal);
    }

    private JLabel crearEtiqueta(
            String texto,
            int tamanio,
            boolean negrita) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(new Font(
                "Arial",
                negrita ? Font.BOLD : Font.PLAIN,
                tamanio
        ));

        etiqueta.setForeground(new Color(30, 55, 82));

        return etiqueta;
    }

    private void cargarPerfil() {

        etiquetaEstado.setText("Cargando información...");

        new SwingWorker<RankingJugador, Void>() {

            @Override
            protected RankingJugador doInBackground()
                    throws Exception {

                RankingSupabaseDAO dao = new RankingSupabaseDAO();

                List<RankingJugador> jugadores =
                        dao.obtenerRanking(sesion);

                for (RankingJugador jugador : jugadores) {

                    if (jugador.obtenerNombreUsuario()
                            .equals(nombreUsuario)) {

                        return jugador;
                    }
                }

                return null;
            }

            @Override
            protected void done() {

                try {

                    RankingJugador jugador = get();

                    if (jugador == null) {

                        etiquetaEstado.setText(
                                "No se encontraron estadísticas."
                        );

                        return;
                    }

                    etiquetaPartidas.setText(
                            "Partidas jugadas: "
                                    + jugador.obtenerPartidasJugadas()
                    );

                    etiquetaVictorias.setText(
                            "Victorias: "
                                    + jugador.obtenerVictorias()
                    );

                    etiquetaEmpates.setText(
                            "Empates: "
                                    + jugador.obtenerEmpates()
                    );

                    etiquetaDerrotas.setText(
                            "Derrotas: "
                                    + jugador.obtenerDerrotas()
                    );

                    etiquetaEstado.setText(
                            "Perfil actualizado correctamente."
                    );

                } catch (Exception e) {

                    etiquetaEstado.setText(
                            "No fue posible cargar el perfil."
                    );

                    JOptionPane.showMessageDialog(
                            VentanaPerfil.this,
                            "Error al consultar el perfil:\n"
                                    + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }

        }.execute();
    }
}
