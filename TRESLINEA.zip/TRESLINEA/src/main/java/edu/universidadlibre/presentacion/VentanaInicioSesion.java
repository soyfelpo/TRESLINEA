
package edu.universidadlibre.presentacion;

import edu.universidadlibre.dao.supabase.AutenticacionSupabaseDAO;
import edu.universidadlibre.dao.supabase.JugadorSupabaseDAO;
import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.servicio.AutenticacionServicio;

import javax.swing.*;
import java.awt.*;

public class VentanaInicioSesion extends JFrame {

    private JTextField campoCorreo;
    private JPasswordField campoContrasena;
    private JButton botonIngresar;
    private JButton botonRegistro;
    private JLabel mensaje;

    private AutenticacionSupabaseDAO autenticacionDAO;
    private JugadorSupabaseDAO jugadorDAO;
    private AutenticacionServicio servicio;

    private String nombrePrimerJugador;
    private SesionSupabase sesionPrimerJugador;

    public VentanaInicioSesion() {
        this(null, null);
    }

    // Constructor para solicitar el inicio de sesión del segundo jugador
    public VentanaInicioSesion(
            String nombrePrimerJugador,
            SesionSupabase sesionPrimerJugador) {

        this.nombrePrimerJugador = nombrePrimerJugador;
        this.sesionPrimerJugador = sesionPrimerJugador;

        autenticacionDAO = new AutenticacionSupabaseDAO();
        jugadorDAO = new JugadorSupabaseDAO();
        servicio = new AutenticacionServicio(autenticacionDAO);

        configurarVentana();
        crearComponentes();
    }

    private void configurarVentana() {

        setTitle("Tres en Línea - Iniciar sesión");
        setSize(450, 570);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void crearComponentes() {

        JPanel panel = new JPanel();
        panel.setBackground(new Color(27, 31, 42));
        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 35, 10, 35);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel titulo = new JLabel("TRES EN LÍNEA", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 30));
        titulo.setForeground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(titulo, gbc);

        String textoSubtitulo = sesionPrimerJugador == null
                ? "Inicia sesión para jugar"
                : "Inicio de sesión del segundo jugador";

        JLabel subtitulo = new JLabel(
                textoSubtitulo,
                SwingConstants.CENTER
        );

        subtitulo.setFont(new Font("Arial", Font.PLAIN, 15));
        subtitulo.setForeground(new Color(180, 190, 205));

        gbc.gridy = 1;
        panel.add(subtitulo, gbc);

        gbc.gridy = 2;
        panel.add(crearEtiqueta("Correo electrónico"), gbc);

        campoCorreo = new JTextField();
        configurarCampo(campoCorreo);

        gbc.gridy = 3;
        panel.add(campoCorreo, gbc);

        gbc.gridy = 4;
        panel.add(crearEtiqueta("Contraseña"), gbc);

        campoContrasena = new JPasswordField();
        configurarCampo(campoContrasena);

        gbc.gridy = 5;
        panel.add(campoContrasena, gbc);

        botonIngresar = new JButton("INICIAR SESIÓN");
        configurarBoton(botonIngresar);

        gbc.gridy = 6;
        gbc.insets = new Insets(20, 35, 8, 35);
        panel.add(botonIngresar, gbc);

        botonRegistro = new JButton("CREAR CUENTA");
        botonRegistro.setFont(new Font("Arial", Font.BOLD, 14));
        botonRegistro.setBackground(new Color(34, 40, 49));
        botonRegistro.setForeground(Color.WHITE);
        botonRegistro.setFocusPainted(false);
        botonRegistro.setBorder(
                BorderFactory.createLineBorder(new Color(49, 118, 150))
        );

        gbc.gridy = 7;
        gbc.insets = new Insets(8, 35, 8, 35);
        panel.add(botonRegistro, gbc);

        mensaje = new JLabel(" ", SwingConstants.CENTER);
        mensaje.setForeground(new Color(255, 120, 120));
        mensaje.setFont(new Font("Arial", Font.PLAIN, 13));

        gbc.gridy = 8;
        panel.add(mensaje, gbc);

        botonIngresar.addActionListener(e -> iniciarSesion());

        campoContrasena.addActionListener(e -> iniciarSesion());

        botonRegistro.addActionListener(e -> {
            new VentanaRegistro().setVisible(true);
        });

        add(panel);
    }

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 14));

        return etiqueta;
    }

    private void configurarCampo(JTextField campo) {

        campo.setFont(new Font("Arial", Font.PLAIN, 15));
        campo.setPreferredSize(new Dimension(300, 40));
        campo.setBackground(new Color(34, 40, 49));
        campo.setForeground(Color.WHITE);
        campo.setCaretColor(Color.WHITE);

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(65, 75, 90)
                        ),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                )
        );
    }

    private void configurarBoton(JButton boton) {

        boton.setFont(new Font("Arial", Font.BOLD, 15));
        boton.setBackground(new Color(49, 118, 150));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void iniciarSesion() {

        String correo = campoCorreo.getText().trim();

        String contrasena = new String(
                campoContrasena.getPassword()
        );

        if (correo.isBlank() || contrasena.isBlank()) {
            mensaje.setText("Completa todos los campos.");
            return;
        }

        botonIngresar.setEnabled(false);
        mensaje.setForeground(Color.WHITE);
        mensaje.setText("Conectando con Supabase...");

        SwingWorker<String, Void> trabajador = new SwingWorker<>() {

            @Override
            protected String doInBackground() {

                String resultado = servicio.iniciarSesion(
                        correo,
                        contrasena
                );

                if ("INICIO_SESION_EXITOSO".equals(resultado)) {

                    SesionSupabase sesion =
                            autenticacionDAO.obtenerSesion();

                    String nombre =
                            jugadorDAO.buscarNombreUsuario(sesion);

                    if (nombre != null) {
                        return "BIENVENIDO:" + nombre;
                    }

                    autenticacionDAO.cerrarSesion();
                    return "PERFIL_NO_ENCONTRADO";
                }

                return resultado;
            }

            @Override
            protected void done() {

                botonIngresar.setEnabled(true);

                try {

                    String resultado = get();

                    if (resultado.startsWith("BIENVENIDO:")) {

                        String nombre = resultado.substring(
                                "BIENVENIDO:".length()
                        );

                        SesionSupabase sesion =
                                autenticacionDAO.obtenerSesion();

                        if (sesionPrimerJugador == null) {

                            VentanaMenuPrincipal menu =
                                    new VentanaMenuPrincipal(
                                            nombre,
                                            sesion
                                    );

                            menu.setVisible(true);

                        } else {

                            if (sesionPrimerJugador.obtenerIdUsuario()
                                    .equals(sesion.obtenerIdUsuario())) {

                                autenticacionDAO.cerrarSesion();

                                mensaje.setForeground(
                                        new Color(255, 120, 120)
                                );

                                mensaje.setText(
                                        "Debes utilizar otra cuenta."
                                );

                                return;
                            }

                            VentanaJuego ventana = new VentanaJuego(
                                    nombrePrimerJugador,
                                    sesionPrimerJugador,
                                    nombre,
                                    sesion
                            );

                            ventana.setVisible(true);
                        }

                        dispose();

                    } else {

                        mensaje.setForeground(
                                new Color(255, 120, 120)
                        );

                        mensaje.setText(
                                resultado.equals("PERFIL_NO_ENCONTRADO")
                                        ? "No se encontró el perfil del jugador."
                                        : resultado
                        );
                    }

                } catch (Exception e) {

                    mensaje.setForeground(
                            new Color(255, 120, 120)
                    );

                    mensaje.setText("Error al iniciar sesión.");
                }
            }
        };

        trabajador.execute();
    }
}
