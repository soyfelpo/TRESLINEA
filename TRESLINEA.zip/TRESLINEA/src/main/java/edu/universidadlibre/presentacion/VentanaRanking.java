
package edu.universidadlibre.presentacion;

import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.dao.supabase.RankingSupabaseDAO;
import edu.universidadlibre.modelo.RankingJugador;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class VentanaRanking extends JFrame {

    private String nombreUsuario;
    private SesionSupabase sesion;

    private JTable tablaRanking;
    private DefaultTableModel modeloTabla;
    private JLabel etiquetaEstado;

    public VentanaRanking(String nombreUsuario, SesionSupabase sesion) {

        this.nombreUsuario = nombreUsuario;
        this.sesion = sesion;

        setTitle("Ranking de Jugadores - Tres en Línea");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        crearComponentes();
        cargarRanking();
    }

    private void crearComponentes() {

        Color azulOscuro = new Color(30, 55, 82);
        Color azulBoton = new Color(39, 83, 125);

        JLabel titulo = new JLabel(
                "RANKING DE JUGADORES",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 25));
        titulo.setForeground(azulOscuro);
        titulo.setBorder(BorderFactory.createEmptyBorder(25, 10, 15, 10));

        add(titulo, BorderLayout.NORTH);

        String[] columnas = {
                "Posición",
                "Jugador",
                "Partidas",
                "Victorias",
                "Empates",
                "Derrotas"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaRanking = new JTable(modeloTabla);
        tablaRanking.setFont(new Font("Arial", Font.PLAIN, 14));
        tablaRanking.setRowHeight(32);
        tablaRanking.getTableHeader().setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        JScrollPane desplazamiento = new JScrollPane(tablaRanking);
        desplazamiento.setBorder(
                BorderFactory.createEmptyBorder(10, 25, 10, 25)
        );

        add(desplazamiento, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout(10, 10));
        panelInferior.setBorder(
                BorderFactory.createEmptyBorder(10, 25, 20, 25)
        );

        etiquetaEstado = new JLabel(" ");
        etiquetaEstado.setFont(new Font("Arial", Font.PLAIN, 13));

        JButton botonActualizar = new JButton("ACTUALIZAR");
        botonActualizar.setBackground(azulBoton);
        botonActualizar.setForeground(Color.WHITE);
        botonActualizar.setFocusPainted(false);

        JButton botonVolver = new JButton("VOLVER");
        botonVolver.setBackground(azulOscuro);
        botonVolver.setForeground(Color.WHITE);
        botonVolver.setFocusPainted(false);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.add(botonActualizar);
        panelBotones.add(botonVolver);

        panelInferior.add(etiquetaEstado, BorderLayout.CENTER);
        panelInferior.add(panelBotones, BorderLayout.EAST);

        add(panelInferior, BorderLayout.SOUTH);

        botonActualizar.addActionListener(e -> cargarRanking());

        botonVolver.addActionListener(e -> {
            new VentanaMenuPrincipal(nombreUsuario, sesion).setVisible(true);
            dispose();
        });
    }

    private void cargarRanking() {

        etiquetaEstado.setText("Cargando ranking...");
        modeloTabla.setRowCount(0);

        new SwingWorker<List<RankingJugador>, Void>() {

            @Override
            protected List<RankingJugador> doInBackground()
                    throws Exception {

                RankingSupabaseDAO dao = new RankingSupabaseDAO();
                return dao.obtenerRanking(sesion);
            }

            @Override
            protected void done() {

                try {

                    List<RankingJugador> jugadores = get();

                    int posicion = 1;

                    for (RankingJugador jugador : jugadores) {

                        modeloTabla.addRow(new Object[]{
                                posicion,
                                jugador.obtenerNombreUsuario(),
                                jugador.obtenerPartidasJugadas(),
                                jugador.obtenerVictorias(),
                                jugador.obtenerEmpates(),
                                jugador.obtenerDerrotas()
                        });

                        posicion++;
                    }

                    if (jugadores.isEmpty()) {
                        etiquetaEstado.setText(
                                "Todavía no hay jugadores registrados."
                        );
                    } else {
                        etiquetaEstado.setText(
                                "Ranking actualizado correctamente."
                        );
                    }

                } catch (Exception e) {

                    etiquetaEstado.setText(
                            "No fue posible cargar el ranking."
                    );

                    JOptionPane.showMessageDialog(
                            VentanaRanking.this,
                            "Error al consultar el ranking:\n"
                                    + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }

        }.execute();
    }
}
