
package edu.universidadlibre.presentacion;

import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.dao.supabase.PartidaSupabaseDAO;
import edu.universidadlibre.modelo.Jugador;
import edu.universidadlibre.modelo.Partida;
import edu.universidadlibre.modelo.Juego;

import javax.swing.*;
import java.awt.*;
import java.util.UUID;

public class VentanaJuego extends JFrame {

    private String nombreUsuario;
    private String nombreSegundoJugador;

    private SesionSupabase sesionJugadorX;
    private SesionSupabase sesionJugadorO;

    private Partida partida;
    private Juego juego;

    private JButton[][] botones;
    private JLabel etiquetaTurno;

    private boolean guardandoResultado;

    private final Color azul = new Color(39, 83, 125);
    private final Color fondo = new Color(248, 249, 251);

    public VentanaJuego(
            String nombreUsuario,
            SesionSupabase sesionJugadorX,
            String nombreSegundoJugador,
            SesionSupabase sesionJugadorO) {

        this.nombreUsuario = nombreUsuario;
        this.nombreSegundoJugador = nombreSegundoJugador;
        this.sesionJugadorX = sesionJugadorX;
        this.sesionJugadorO = sesionJugadorO;

        iniciarPartida();
        configurarVentana();
        crearComponentes();
    }

    private void iniciarPartida() {

        UUID idJugadorX = UUID.fromString(
                sesionJugadorX.obtenerIdUsuario()
        );

        UUID idJugadorO = UUID.fromString(
                sesionJugadorO.obtenerIdUsuario()
        );

        Jugador jugadorX = new Jugador(
                nombreUsuario,
                idJugadorX
        );

        Jugador jugadorO = new Jugador(
                nombreSegundoJugador,
                idJugadorO
        );

        partida = new Partida(jugadorX, jugadorO);
        juego = partida.obtenerJuego();

        guardandoResultado = false;
    }

    private void configurarVentana() {

        setTitle("Tres en Línea - Partida");
        setSize(600, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void crearComponentes() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(fondo);
        principal.setBorder(
                BorderFactory.createEmptyBorder(25, 35, 25, 35)
        );

        JLabel titulo = new JLabel(
                "NUEVA PARTIDA",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(azul);

        principal.add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(10, 20));
        centro.setBackground(fondo);
        centro.setBorder(
                BorderFactory.createEmptyBorder(25, 20, 15, 20)
        );

        JPanel jugadores = new JPanel(new GridLayout(1, 2, 20, 0));
        jugadores.setBackground(fondo);

        JLabel jugadorX = new JLabel(
                "X: " + nombreUsuario,
                SwingConstants.CENTER
        );

        JLabel jugadorO = new JLabel(
                "O: " + nombreSegundoJugador,
                SwingConstants.CENTER
        );

        jugadorX.setFont(new Font("Arial", Font.BOLD, 15));
        jugadorO.setFont(new Font("Arial", Font.BOLD, 15));

        jugadores.add(jugadorX);
        jugadores.add(jugadorO);

        centro.add(jugadores, BorderLayout.NORTH);

        JPanel tablero = new JPanel(new GridLayout(3, 3, 5, 5));
        tablero.setBackground(azul);
        tablero.setBorder(
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        );

        botones = new JButton[3][3];

        for (int fila = 0; fila < 3; fila++) {

            for (int columna = 0; columna < 3; columna++) {

                final int f = fila;
                final int c = columna;

                JButton boton = new JButton("");

                boton.setFont(new Font("Arial", Font.BOLD, 55));
                boton.setBackground(Color.WHITE);
                boton.setForeground(azul);
                boton.setFocusPainted(false);

                boton.addActionListener(e -> jugar(f, c));

                botones[fila][columna] = boton;
                tablero.add(boton);
            }
        }

        tablero.setPreferredSize(new Dimension(380, 380));

        JPanel contenedorTablero = new JPanel(new GridBagLayout());
        contenedorTablero.setBackground(fondo);
        contenedorTablero.add(tablero);

        centro.add(contenedorTablero, BorderLayout.CENTER);

        etiquetaTurno = new JLabel(
                "Turno de " + nombreUsuario + " (X)",
                SwingConstants.CENTER
        );

        etiquetaTurno.setFont(new Font("Arial", Font.BOLD, 17));
        etiquetaTurno.setForeground(azul);

        centro.add(etiquetaTurno, BorderLayout.SOUTH);

        principal.add(centro, BorderLayout.CENTER);

        JButton volver = new JButton("VOLVER AL MENÚ");
        volver.setFont(new Font("Arial", Font.BOLD, 14));
        volver.setBackground(azul);
        volver.setForeground(Color.WHITE);
        volver.setFocusPainted(false);

        volver.addActionListener(e -> volverAlMenu());

        JPanel pie = new JPanel();
        pie.setBackground(fondo);
        pie.add(volver);

        principal.add(pie, BorderLayout.SOUTH);

        add(principal);
    }

    private void jugar(int fila, int columna) {

        if (guardandoResultado) {
            return;
        }

        if (!juego.jugar(fila, columna)) {
            return;
        }

        String ficha = juego.obtenerTablero()
                .obtenerFicha(fila, columna);

        botones[fila][columna].setText(ficha);
        botones[fila][columna].setEnabled(false);

        if (juego.obtenerGanador() != null) {

            finalizarPartida(
                    "¡Ganó " + obtenerNombreGanador() + "!"
            );

            return;
        }

        if (juego.obtenerTablero().hayEmpate()) {

            finalizarPartida("La partida terminó en empate.");
            return;
        }

        actualizarTurno();
    }

    private String obtenerNombreGanador() {

        if ("X".equals(juego.obtenerGanador())) {
            return nombreUsuario;
        }

        return nombreSegundoJugador;
    }

    private void actualizarTurno() {

        if ("X".equals(juego.obtenerTurno())) {

            etiquetaTurno.setText(
                    "Turno de " + nombreUsuario + " (X)"
            );

        } else {

            etiquetaTurno.setText(
                    "Turno de " + nombreSegundoJugador + " (O)"
            );
        }
    }

    private void finalizarPartida(String resultado) {

        if (guardandoResultado) {
            return;
        }

        guardandoResultado = true;

        etiquetaTurno.setText("Guardando resultado en Supabase...");

        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                botones[fila][columna].setEnabled(false);
            }
        }

        SwingWorker<Boolean, Void> trabajador =
                new SwingWorker<>() {

                    @Override
                    protected Boolean doInBackground() {

                        PartidaSupabaseDAO dao =
                                new PartidaSupabaseDAO();

                        return dao.guardar(partida, sesionJugadorX);
                    }

                    @Override
                    protected void done() {

                        boolean guardado = false;

                        try {
                            guardado = get();
                        } catch (Exception e) {
                            guardado = false;
                        }

                        mostrarOpcionesFinalizacion(
                                resultado,
                                guardado
                        );
                    }
                };

        trabajador.execute();
    }

    private void mostrarOpcionesFinalizacion(
            String resultado,
            boolean guardado) {

        String mensaje;

        if (guardado) {

            mensaje = resultado
                    + "\n\nEl resultado se guardó correctamente en Supabase.";

        } else {

            mensaje = resultado
                    + "\n\nNo fue posible guardar el resultado en Supabase."
                    + "\nPuedes continuar jugando, pero esta partida no quedó registrada.";
        }

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Partida finalizada",
                guardado
                        ? JOptionPane.INFORMATION_MESSAGE
                        : JOptionPane.WARNING_MESSAGE
        );

        String[] opciones = {
                "JUGAR OTRA VEZ",
                "VOLVER AL MENÚ"
        };

        int respuesta = JOptionPane.showOptionDialog(
                this,
                "¿Qué deseas hacer?",
                "Continuar",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (respuesta == 0) {
            reiniciarPartida();
        } else {
            volverAlMenu();
        }
    }

    private void reiniciarPartida() {

        iniciarPartida();

        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {

                botones[fila][columna].setText("");
                botones[fila][columna].setEnabled(true);
            }
        }

        etiquetaTurno.setText(
                "Turno de " + nombreUsuario + " (X)"
        );
    }

    private void volverAlMenu() {

        dispose();

        new VentanaMenuPrincipal(
                nombreUsuario,
                sesionJugadorX
        ).setVisible(true);
    }
}
