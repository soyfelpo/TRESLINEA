
package edu.universidadlibre.configuracion;

import java.net.URI;
import java.net.http.HttpClient;
import java.time.Duration;

public class ConexionSupabase {

    private static final String URL_SUPABASE =
            "https://udkrdpbvhcggbxyjfnnb.supabase.co";

    private static final String CLAVE_SUPABASE =
            System.getenv("SUPABASE_PUBLISHABLE_KEY");

    private static final HttpClient CLIENTE = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20))
            .build();

    public static HttpClient obtenerCliente() {
        return CLIENTE;
    }

    public static URI obtenerUrl(String recurso) {
        return URI.create(URL_SUPABASE + recurso);
    }

    public static String obtenerClave() {
        if (CLAVE_SUPABASE == null || CLAVE_SUPABASE.isBlank()) {
            throw new IllegalStateException(
                    "No se ha configurado SUPABASE_PUBLISHABLE_KEY"
            );
        }

        return CLAVE_SUPABASE;
    }
}
