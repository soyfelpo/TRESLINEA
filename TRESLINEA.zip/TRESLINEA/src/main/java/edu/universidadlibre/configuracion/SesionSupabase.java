
package edu.universidadlibre.configuracion;
public class SesionSupabase {
    private String accessToken;
    private String refreshToken;
    private String idUsuario;
    private String correo;
    public SesionSupabase(
            String accessToken,
            String refreshToken,
            String idUsuario,
            String correo) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.idUsuario = idUsuario;
        this.correo = correo;
    }
    public String obtenerAccessToken() {
        return accessToken;
    }
    public String obtenerRefreshToken() {
        return refreshToken;
    }
    public String obtenerIdUsuario() {
        return idUsuario;
    }
    public String obtenerCorreo() {
        return correo;
    }
    public boolean estaActiva() {
        return accessToken != null
                && !accessToken.isBlank();
    }
    public void cerrarSesion() {
        accessToken = null;
        refreshToken = null;
        idUsuario = null;
        correo = null;
    }
}
