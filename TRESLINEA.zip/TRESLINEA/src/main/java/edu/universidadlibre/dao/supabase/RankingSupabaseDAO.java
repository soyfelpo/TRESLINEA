
package edu.universidadlibre.dao.supabase;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.universidadlibre.configuracion.ConexionSupabase;
import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.modelo.RankingJugador;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class RankingSupabaseDAO {

    private final ObjectMapper conversor = new ObjectMapper();

    public List<RankingJugador> obtenerRanking(
            SesionSupabase sesion) throws Exception {

        if (sesion == null || !sesion.estaActiva()) {
            throw new IllegalStateException(
                    "No hay una sesión activa."
            );
        }

        String recurso =
                "/rest/v1/ranking_jugadores"
                        + "?select=nombre_usuario,partidas_jugadas,"
                        + "victorias,empates,derrotas"
                        + "&order=victorias.desc,empates.desc,nombre_usuario.asc";

        HttpRequest solicitud = HttpRequest.newBuilder()
                .uri(ConexionSupabase.obtenerUrl(recurso))
                .header("apikey", ConexionSupabase.obtenerClave())
                .header(
                        "Authorization",
                        "Bearer " + sesion.obtenerAccessToken()
                )
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> respuesta =
                ConexionSupabase.obtenerCliente().send(
                        solicitud,
                        HttpResponse.BodyHandlers.ofString()
                );

        if (respuesta.statusCode() != 200) {
            throw new IllegalStateException(
                    "Error al consultar el ranking. Código: "
                            + respuesta.statusCode()
                            + ". Respuesta: " + respuesta.body()
            );
        }

        JsonNode datos = conversor.readTree(respuesta.body());

        List<RankingJugador> ranking = new ArrayList<>();

        for (JsonNode jugador : datos) {

            RankingJugador registro = new RankingJugador(
                    jugador.get("nombre_usuario").asText(),
                    jugador.get("partidas_jugadas").asInt(),
                    jugador.get("victorias").asInt(),
                    jugador.get("empates").asInt(),
                    jugador.get("derrotas").asInt()
            );

            ranking.add(registro);
        }

        return ranking;
    }
}
