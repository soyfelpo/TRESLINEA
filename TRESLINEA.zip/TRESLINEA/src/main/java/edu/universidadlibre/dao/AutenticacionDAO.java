package edu.universidadlibre.dao;
public interface AutenticacionDAO {
    String registrar(
            String correo,
            String contrasena,
            String nombreUsuario
    );
    String iniciarSesion(
            String correo,
            String contrasena
    );
}
