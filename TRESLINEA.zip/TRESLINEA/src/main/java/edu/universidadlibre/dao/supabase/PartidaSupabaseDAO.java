
package edu.universidadlibre.dao.supabase;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.universidadlibre.configuracion.ConexionSupabase;
import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.modelo.Jugador;
import edu.universidadlibre.modelo.Partida;
import edu.universidadlibre.modelo.ResultadoPartida;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class PartidaSupabaseDAO {

    private final ObjectMapper conversor = new ObjectMapper();

    public boolean guardar(Partida partida, SesionSupabase sesion) {

        if (partida == null || sesion == null || !sesion.estaActiva()) {
            return false;
        }

        if (!partida.estaFinalizada()) {
            return false;
        }

        try {

            Jugador jugadorX = partida.obtenerJugadorX();
            Jugador jugadorO = partida.obtenerJugadorO();

            if (jugadorX == null || jugadorO == null) {
                return false;
            }

            UUID idJugadorX = jugadorX.obtenerId();
            UUID idJugadorO = jugadorO.obtenerId();

            if (idJugadorX == null || idJugadorO == null) {
                return false;
            }

            String idUsuario = sesion.obtenerIdUsuario();

            if (idUsuario == null) {
                return false;
            }

            UUID idAutenticado = UUID.fromString(idUsuario);

            if (!idAutenticado.equals(idJugadorX)
                    && !idAutenticado.equals(idJugadorO)) {
                return false;
            }

            ResultadoPartida resultado = new ResultadoPartida(partida);

            String tipoResultado = resultado.obtenerTipoResultado();

            UUID idGanador = null;

            if (!"EMPATE".equals(tipoResultado)) {

                Jugador ganador = resultado.obtenerGanador();

                if (ganador == null) {
                    return false;
                }

                idGanador = ganador.obtenerId();
            }

            DateTimeFormatter formato =
                    DateTimeFormatter.ISO_LOCAL_DATE_TIME;

            String fechaInicio = partida.obtenerFechaInicio()
                    .atZone(java.time.ZoneId.systemDefault())
                    .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);

            String fechaFin = partida.obtenerFechaFin()
                    .atZone(java.time.ZoneId.systemDefault())
                    .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);

            String cuerpo = """
                    {
                        "p_jugador_x_id": "%s",
                        "p_jugador_o_id": "%s",
                        "p_ganador_id": %s,
                        "p_resultado": "%s",
                        "p_fecha_inicio": "%s",
                        "p_fecha_fin": "%s"
                    }
                    """.formatted(
                    idJugadorX,
                    idJugadorO,
                    idGanador == null ? "null" : "\"" + idGanador + "\"",
                    tipoResultado,
                    fechaInicio,
                    fechaFin
            );

            HttpRequest solicitud = HttpRequest.newBuilder()
                    .uri(ConexionSupabase.obtenerUrl(
                            "/rest/v1/rpc/guardar_partida"
                    ))
                    .header("apikey", ConexionSupabase.obtenerClave())
                    .header("Authorization",
                            "Bearer " + sesion.obtenerAccessToken())
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(cuerpo))
                    .build();

            HttpResponse<String> respuesta =
                    ConexionSupabase.obtenerCliente().send(
                            solicitud,
                            HttpResponse.BodyHandlers.ofString()
                    );

            return respuesta.statusCode() == 200;

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
            return false;

        } catch (Exception e) {

            return false;
        }
    }
}
