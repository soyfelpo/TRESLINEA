
package edu.universidadlibre.dao.supabase;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.universidadlibre.configuracion.ConexionSupabase;
import edu.universidadlibre.configuracion.SesionSupabase;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class JugadorSupabaseDAO {

    private final ObjectMapper conversor = new ObjectMapper();

    public String buscarNombreUsuario(SesionSupabase sesion) {

        if (sesion == null || !sesion.estaActiva()) {
            return null;
        }

        try {

            String recurso = "/rest/v1/jugadores?id=eq."
                    + sesion.obtenerIdUsuario()
                    + "&select=nombre_usuario";

            HttpRequest solicitud = HttpRequest.newBuilder()
                    .uri(ConexionSupabase.obtenerUrl(recurso))
                    .header("apikey", ConexionSupabase.obtenerClave())
                    .header(
                            "Authorization",
                            "Bearer " + sesion.obtenerAccessToken()
                    )
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> respuesta =
                    ConexionSupabase.obtenerCliente().send(
                            solicitud,
                            HttpResponse.BodyHandlers.ofString()
                    );

            if (respuesta.statusCode() != 200) {
                return null;
            }

            JsonNode datos = conversor.readTree(respuesta.body());

            if (!datos.isArray() || datos.isEmpty()) {
                return null;
            }

            return datos.get(0)
                    .path("nombre_usuario")
                    .asText(null);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
            return null;

        } catch (Exception e) {

            return null;
        }
    }
}
