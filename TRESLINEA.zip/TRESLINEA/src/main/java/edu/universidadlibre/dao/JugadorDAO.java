package edu.universidadlibre.dao;

import edu.universidadlibre.modelo.Jugador;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface JugadorDAO {

    void guardar(Jugador jugador);

    Optional<Jugador> buscarPorId(UUID id);

    Optional<Jugador> buscarPorNombreUsuario(String nombreUsuario);

    List<Jugador> listarJugadores();
}