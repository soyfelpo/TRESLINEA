package edu.universidadlibre.dao.supabase;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import edu.universidadlibre.configuracion.ConexionSupabase;
import edu.universidadlibre.configuracion.SesionSupabase;
import edu.universidadlibre.dao.AutenticacionDAO;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
public class AutenticacionSupabaseDAO implements AutenticacionDAO {
    private final ObjectMapper conversor = new ObjectMapper();
    private SesionSupabase sesion;
    public SesionSupabase obtenerSesion() {
        return sesion;
    }
    @Override
    public String registrar(
            String correo,
            String contrasena,
            String nombreUsuario) {
        try {
            ObjectNode datos = conversor.createObjectNode();
            datos.put("email", correo);
            datos.put("password", contrasena);
            ObjectNode informacionUsuario =
                    conversor.createObjectNode();
            informacionUsuario.put("nombre_usuario", nombreUsuario);
            datos.set("data", informacionUsuario);
            String cuerpo = conversor.writeValueAsString(datos);
            HttpRequest solicitud = HttpRequest.newBuilder()
                    .uri(ConexionSupabase.obtenerUrl("/auth/v1/signup"))
                    .header("apikey", ConexionSupabase.obtenerClave())
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            cuerpo, StandardCharsets.UTF_8
                    ))
                    .build();
            HttpResponse<String> respuesta =
                    ConexionSupabase.obtenerCliente().send(
                            solicitud,
                            HttpResponse.BodyHandlers.ofString()
                    );
            if (respuesta.statusCode() == 200
                    || respuesta.statusCode() == 201) {
                JsonNode datosRespuesta =
                        conversor.readTree(respuesta.body());
                if (datosRespuesta.hasNonNull("access_token")) {
                    return "REGISTRO_EXITOSO";
                }
                return "REGISTRO_PENDIENTE_CONFIRMACION";
            }
            return obtenerError(respuesta.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "ERROR_DE_CONEXION";
        } catch (Exception e) {
            return "ERROR_DE_CONEXION";
        }
    }
    @Override
    public String iniciarSesion(
            String correo,
            String contrasena) {
        try {
            ObjectNode datos = conversor.createObjectNode();
            datos.put("email", correo);
            datos.put("password", contrasena);
            String cuerpo = conversor.writeValueAsString(datos);
            HttpRequest solicitud = HttpRequest.newBuilder()
                    .uri(ConexionSupabase.obtenerUrl(
                            "/auth/v1/token?grant_type=password"
                    ))
                    .header("apikey", ConexionSupabase.obtenerClave())
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            cuerpo, StandardCharsets.UTF_8
                    ))
                    .build();
            HttpResponse<String> respuesta =
                    ConexionSupabase.obtenerCliente().send(
                            solicitud,
                            HttpResponse.BodyHandlers.ofString()
                    );
            if (respuesta.statusCode() == 200) {
                JsonNode datosRespuesta =
                        conversor.readTree(respuesta.body());
                String accessToken =
                        datosRespuesta.path("access_token").asText();
                String refreshToken =
                        datosRespuesta.path("refresh_token").asText();
                String idUsuario =
                        datosRespuesta.path("user").path("id").asText();
                String correoUsuario =
                        datosRespuesta.path("user").path("email").asText();
                if (accessToken.isBlank()
                        || refreshToken.isBlank()
                        || idUsuario.isBlank()) {
                    return "ERROR_EN_DATOS_DE_SESION";
                }
                sesion = new SesionSupabase(
                        accessToken,
                        refreshToken,
                        idUsuario,
                        correoUsuario
                );
                return "INICIO_SESION_EXITOSO";
            }
            return obtenerError(respuesta.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "ERROR_DE_CONEXION";
        } catch (Exception e) {
            return "ERROR_DE_CONEXION";
        }
    }
    public void cerrarSesion() {
        if (sesion != null) {
            sesion.cerrarSesion();
            sesion = null;
        }
    }
    private String obtenerError(String cuerpo) {
        try {
            JsonNode respuesta = conversor.readTree(cuerpo);
            JsonNode mensaje = respuesta.get("msg");
            if (mensaje == null) {
                mensaje = respuesta.get("message");
            }
            if (mensaje == null) {
                mensaje = respuesta.get("error_description");
            }
            if (mensaje == null) {
                mensaje = respuesta.get("error");
            }
            if (mensaje != null && mensaje.isTextual()) {
                return mensaje.asText();
            }
            return "ERROR_EN_AUTENTICACION";
        } catch (Exception e) {
            return "ERROR_EN_AUTENTICACION";
        }
    }
}