package edu.universidadlibre.dao;

import edu.universidadlibre.modelo.Partida;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PartidaDAO {

    void guardar(Partida partida);

    Optional<Partida> buscarPorId(UUID id);

    List<Partida> listarPartidas();

    List<Partida> buscarPorJugador(UUID jugadorId);
}
