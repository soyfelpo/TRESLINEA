package edu.universidadlibre.servicio;
import edu.universidadlibre.dao.AutenticacionDAO;
public class AutenticacionServicio {
    private AutenticacionDAO autenticacionDAO;
    public AutenticacionServicio() {
        this.autenticacionDAO = null;
    }
    public AutenticacionServicio(AutenticacionDAO autenticacionDAO) {
        this.autenticacionDAO = autenticacionDAO;
    }
    public String validarDatosRegistro(
            String correo,
            String contrasena,
            String nombreUsuario) {
        if (correo == null || correo.isBlank()) {
            return "El correo es obligatorio";
        }
        if (contrasena == null || contrasena.isBlank()) {
            return "La contraseña es obligatoria";
        }
        if (nombreUsuario == null || nombreUsuario.isBlank()) {
            return "El nombre de usuario es obligatorio";
        }
        if (!correo.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            return "El correo no tiene un formato válido";
        }
        if (nombreUsuario.length() > 30) {
            return "El nombre de usuario no puede superar 30 caracteres";
        }
        return null;
    }
    public String registrar(
            String correo,
            String contrasena,
            String nombreUsuario) {
        String error = validarDatosRegistro(
                correo, contrasena, nombreUsuario
        );
        if (error != null) {
            return error;
        }
        if (autenticacionDAO == null) {
            return "El servicio de autenticación no está configurado";
        }
        return autenticacionDAO.registrar(
                correo, contrasena, nombreUsuario
        );
    }
    public String iniciarSesion(String correo, String contrasena) {
        if (correo == null || correo.isBlank()) {
            return "El correo es obligatorio";
        }
        if (contrasena == null || contrasena.isBlank()) {
            return "La contraseña es obligatoria";
        }
        if (autenticacionDAO == null) {
            return "El servicio de autenticación no está configurado";
        }
        return autenticacionDAO.iniciarSesion(correo, contrasena);
    }
}
