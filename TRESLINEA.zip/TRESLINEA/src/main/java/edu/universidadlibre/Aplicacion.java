package edu.universidadlibre;
import edu.universidadlibre.presentacion.VentanaInicioSesion;
import javax.swing.SwingUtilities;
public class Aplicacion {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaInicioSesion ventana =
                    new VentanaInicioSesion();
            ventana.setVisible(true);
        });
    }
}
